package com.example.cotel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    Button buttonSalir;
    Button buttonZona1;
    Button buttonZona2;
    Button buttonZona3;
    Button buttonZona4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSalir = findViewById(R.id.atras);
        buttonZona1 = findViewById(R.id.zona1);
        buttonZona2 = findViewById(R.id.zona2);
        buttonZona3 = findViewById(R.id.zona3);
        buttonZona4 = findViewById(R.id.zona4);

        buttonSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                finish();
            }
        });

        buttonZona1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), ZonaOne.class);
                startActivity(intent);
            }
        });

        buttonZona2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), ZonaTwo.class);
                startActivity(intent);
            }
        });

        buttonZona3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), Zonathree.class);
                startActivity(intent);
            }
        });

        buttonZona4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), Zonafour.class);
                startActivity(intent);
            }
        });
    }
}